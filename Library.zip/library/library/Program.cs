﻿using System;

namespace LibraryManagement
{
    class Book
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public int Year { get; set; }
        public string ISBN { get; set; }

        public void PrintInfo()
        {
            Console.WriteLine("Book Information:");
            Console.WriteLine("Title: "+Title);
            Console.WriteLine("Author: "+Author);
            Console.WriteLine("Year: "+Year);
            Console.WriteLine("ISBN: "+ISBN);
            Console.WriteLine();
        }
    }

    class Member
    {
        public string Name { get; set; }
        public string MemberID { get; set; }
        public string Phone { get; set; }

        public void PrintMemberInfo()
        {
            Console.WriteLine("Member Information:");
            Console.WriteLine("Name: "+Name);
            Console.WriteLine("Member ID: "+MemberID);
            Console.WriteLine("Phone: "+Phone);
            Console.WriteLine();
        }
        
    }
    class Program
    {
        static void Main(string[] args)
        {
            Book book = new Book();
            Console.WriteLine("Enter book details:");
            Console.Write("Title: ");
            book.Title = Console.ReadLine();
            Console.Write("Author: ");
            book.Author = Console.ReadLine();
            Console.Write("Year: ");
            book.Year = int.Parse(Console.ReadLine());
            Console.Write("ISBN: ");
            book.ISBN = Console.ReadLine();
            book.PrintInfo();

            Member member = new Member();
            Console.WriteLine("Enter member details:");
            Console.Write("Name: ");
            member.Name = Console.ReadLine();
            Console.Write("Member ID: ");
            member.MemberID = Console.ReadLine();
            Console.Write("Phone: ");
            member.Phone = Console.ReadLine();
            member.PrintMemberInfo();
            Console.ReadKey();
        }
            }
}


        
    
